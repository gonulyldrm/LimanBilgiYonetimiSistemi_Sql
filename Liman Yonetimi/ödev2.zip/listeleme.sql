Create Proc tedarik�ilist
as
begin
	select * from tedarik�iler
end
go
Create Proc y�neticilist
as
begin
	select * from y�neticiler
end
go
Create Proc limanlist
as
begin
	select * from limanlar
end
go
Create Proc kaptanlist
as
begin
	select * from kaptanlar
end
go
Create Proc illist
as
begin
	select * from iller
end
go
Create Proc il�elist
as
begin
	select * from il�eler
end
go
Create Proc katagorilist
as
begin
	select * from katagoriler
end
go
Create Proc �r�nlist
as
begin
	select * from �r�nler
end
go
Create Proc soforlist
as
begin
	select * from soforler
end
go
Create Proc seferlist
as
begin
	select * from seferler
end
go
Create Proc ara�list
as
begin
	select * from ara�lar
end
go
Create Proc depolist
as
begin
	select * from depolar
end
go
Create Proc m��terilist
as
begin
	select * from m��teriler
end
go
Create Proc kargo�irketilist
as
begin
	select * from kargosirketler
end
go
Create Proc kargoalanlist
as
begin
	select * from kargoalanlar
end
go
Create Proc kargolist
as
begin
	select * from kargolar
end
go
Create Proc ka�akg��menlist
as
begin
	select * from ka�akg��menler
end
go
Create Proc iscilist
as
begin
	select * from isciler
end
go
Create Proc gemilist
as
begin
	select * from gemiler
end
go
Create Proc iadelist
as
begin
	select * from iadeler
end
go
Create Proc sat�lanlist
as
begin
	select * from sat�lanlar
end
go













